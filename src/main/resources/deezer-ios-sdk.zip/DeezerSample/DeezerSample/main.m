#import <UIKit/UIKit.h>

#import "DeezerSampleAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([DeezerSampleAppDelegate class]));
    }
}
