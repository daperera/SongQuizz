//
//  NSDictionary+Utils.h
//  DeezerSample
//
//  Created by Guillaume Mirambeau on 06/01/2017.
//  Copyright © 2017 Deezer. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDictionary (Utils)

- (NSString *)toString;

@end
