//
//  DZRModel.h
//  Deezer
//
//  Created by GFaure on 24/04/2014.
//  Copyright (c) 2014 Deezer. All rights reserved.
//

#import "NSError+DZRModel.h"
#import "DZRObjectList.h"
#import "DZRObject.h"
#import "DZRAlbum.h"
#import "DZRArtist.h"
#import "DZRComment.h"
#import "DZREditorial.h"
#import "DZREpisode.h"
#import "DZRFolder.h"
#import "DZRGenre.h"
#import "DZRPlaylist.h"
#import "DZRPodcast.h"
#import "DZRRadio.h"
#import "DZRManagedRadio.h"
#import "DZRTrack.h"
#import "DZRUser.h"
